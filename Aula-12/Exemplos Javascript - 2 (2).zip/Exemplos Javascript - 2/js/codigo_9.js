              
function validateForm() {
  let x = document.forms["myForm"]["nome"].value;
  let y = document.forms["myForm"]["snome"].value;
  if (x == "" || y == "") {
    alert("Preencher Nome ou Sobrenome");
    return false;
  }
  let s = document.forms["myForm"]["sexo"].value;
   if (s == "" ) {
    alert("Preencher Sexo");
    return false;
  }
}


function alerta(){
	elemento_nome=document.getElementById("nome");
	var conteudo_nome=elemento_nome.value;
	if(conteudo_nome==""){

		alert("Favor preencher o Nome");
		
	}
    else
    {
    	conteudo_div="Bem Vindo(a) " +conteudo_nome;
    	conteudo_div+= "<br> faça também o teste deixando o campo em branco";
    	document.getElementById("texto").innerHTML = conteudo_div;

    }







}
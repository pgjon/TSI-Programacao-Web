              
function validateForm() {
  let x = document.forms["myForm"]["fname"].value;
  let y = document.forms["myForm"]["pass"].value;
  if (x == "" || y == "") {
    alert("Preencher todos os campos");
    return false;
  }
}

